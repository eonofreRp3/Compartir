using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Rp3.AgendaComercial.Common.Models.Fertisa
{

    public partial class GestionCreditoCliente
    {
        public GestionCreditoCliente()
        {
            this.GestionCreditoClienteCupo = new HashSet<GestionCreditoClienteCupo>();
            this.GestionCreditoClienteDireccion = new HashSet<GestionCreditoClienteDireccion>();
            this.GestionCreditoClienteDocumento = new HashSet<GestionCreditoClienteDocumento>();
            this.GestionCreditoClienteFamiliar = new HashSet<GestionCreditoClienteFamiliar>();
            this.GestionCreditoClienteReferencia = new HashSet<GestionCreditoClienteReferencia>();
            this.GestionCreditoClienteSobregiro = new HashSet<GestionCreditoClienteSobregiro>();
            this.GestionCreditoAudit = new HashSet<GestionCreditoAudit>();
        }

        public int IdInterno { get; set; }
        public int IdGestion { get; set; }
        public Nullable<int> IdRegion { get; set; } 
        public string IdTipoContribuyente { get; set; }
        public int IdTipoIdentificacion { get; set; }
        public int IdCliente { get; set; }
        public double CodigoAlterno { get; set; }
        public bool DatosGenerales { get; set; }
        public bool DatosFamiliares { get; set; }
        public bool Referencias { get; set; }
        public bool Documentos { get; set; }
        public bool Garantia { get; set; }
        public string NombreComercial { get; set; }
        public string IdentificacionRepresentante { get; set; }
        public Nullable<int> IdTipoIdentificacionRepresentante { get; set; }
        public string RepresentanteLegal { get; set; }
        public string Nombre1 { get; set; }
        public string IdCiudadNacimiento { get; set; }
        public string Nombre2 { get; set; }
        public string Apellido1 { get; set; }
        public string Apellido2 { get; set; }
        public string NombreCompleto { get; set; }
        public Nullable<int> IdClienteGrupo { get; set; }
        public string CorreoElectronico { get; set; }
        public short GeneroTabla { get; set; }
        public string Genero { get; set; }
        public short EstadoCivilTabla { get; set; }
        public string EstadoCivil { get; set; }

        public DateTime? FechaNacimiento { get; set; }
        public long? FechaNacimientoTicks
        {
            get
            {
                if (FechaNacimiento.HasValue)
                    return FechaNacimiento.Value.Ticks;
                return 0;
            }
            set
            {
                if (value == 0 || value == null)
                    FechaNacimiento = null;
                else
                    FechaNacimiento = new DateTime(value.Value);
            }
        }
        public int IdCategoria { get; set; }
        public Nullable<int> IdTipoCliente { get; set; }
        public string IdPais { get; set; }
        public Nullable<int> IdZona { get; set; }
        public Nullable<short> TablaTipoPersona { get; set; }
        public string TipoPersona { get; set; }
        public string IdParroquia { get; set; }
        public Nullable<short> TablaOrigenIngreso { get; set; }
        public string OrigenIngreso { get; set; }
        public string OrigenIngresoSecundario { get; set; }
        public Nullable<int> OrigenIngresoAnios { get; set; }
        public Nullable<int> OrigenIngresoSecundarioAnios { get; set; }
        public Nullable<short> TipoActividadTabla { get; set; }
        public string IdTipoActividad { get; set; }
        public Nullable<short> TipoViviendaTabla { get; set; }
        public string IdTipoVivienda { get; set; }
        public Nullable<short> ProduccionTabla { get; set; }
        public string IdProduccion { get; set; }
        public string UsrIng { get; set; }
        public System.DateTime FecIng { get; set; }
        public string UsrMod { get; set; }
        public Nullable<System.DateTime> FecMod { get; set; }
        public Nullable<System.DateTime> DateSyncServer { get; set; }
        public Nullable<long> DateSyncServerId { get; set; }
        public Nullable<short> EstadoTabla { get; set; }
        public Nullable<short> LocalHectareaTabla { get; set; }
        public string Estado { get; set; }
        public string LocalHectarea { get; set; }
        public Nullable<decimal> CupoSolicitado { get; set; }
        public Nullable<decimal> CupoActual { get; set; }
        public Nullable<int>  Plazo { get; set; }
        public Nullable<int> Hectarea { get; set; }
        public Nullable<int> HectareasAlquilada { get; set; }
        public Nullable<int> IdTipoCultivo { get; set; }
        public Nullable<int> IdCondicionPago { get; set; }
        public Nullable<int> HaciendaTotales { get; set; }
        public Nullable<int> HaciendaProductivas { get; set; }
    
        public ICollection<GestionCreditoClienteCupo> GestionCreditoClienteCupo { get; set; }
        public ICollection<GestionCreditoClienteDireccion> GestionCreditoClienteDireccion { get; set; }
        public ICollection<GestionCreditoClienteDocumento> GestionCreditoClienteDocumento { get; set; }
        public ICollection<GestionCreditoClienteFamiliar> GestionCreditoClienteFamiliar { get; set; }
        public ICollection<GestionCreditoClienteReferencia> GestionCreditoClienteReferencia { get; set; }
        public ICollection<GestionCreditoClienteSobregiro> GestionCreditoClienteSobregiro { get; set; }
        public ICollection<GestionCreditoAudit> GestionCreditoAudit { get; set; }
    }
}
