﻿using Rp3.Data.Entity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rp3.AgendaComercial.Models.Repositories
{
    public class GestionCreditoRepository : Rp3.Data.Entity.Repository
    {
        public GestionCreditoRepository(DbContext context) : base(context)
        {
        }

        public Common.Models.Fertisa.GestionCreditoResponse GetGestionCredito(DateTime ultimaActualizacion, int page, int pageSize)
        {
            Db.Connection.Open();

            var cmd = Db.Connection.CreateCommand();
            DateTime SqlServerDatetimeMinValue = System.Data.SqlTypes.SqlDateTime.MinValue.Value;
            DateTime MobileDatetimeMinValue = new DateTime(1969, 12, 31, 19, 0, 0);

            var gestionCreditoResponse = new Common.Models.Fertisa.GestionCreditoResponse();

            if (ultimaActualizacion <= MobileDatetimeMinValue)
            {
                ultimaActualizacion = SqlServerDatetimeMinValue;
            }
            else
            {
                ultimaActualizacion.AddMinutes(-15);
            }

            string sqlFormattedDate = ultimaActualizacion.ToString("yyyy-MM-dd HH:mm:ss.fff");

            cmd.CommandText = String.Format("[fertisa].[spGetGestionCredito] @UltimaActualizacion = @UltimaActualizacion, @PageSize = @PageSize, @Page= @Page");
            cmd.Parameters.Add(new SqlParameter("@UltimaActualizacion", SqlDbType.DateTime) { Value = sqlFormattedDate });
            cmd.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int) { Value = pageSize });
            cmd.Parameters.Add(new SqlParameter("@Page", SqlDbType.Int) { Value = page });

            var reader = cmd.ExecuteReader();

            if (reader.HasRows == true)
                gestionCreditoResponse.ResultGestionCreditoFase = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.GestionCreditoFase>(reader).ToList();

            reader.NextResult();

            if (reader.HasRows == true)
                gestionCreditoResponse.ResultGestionCreditoUsuario = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.GestionCreditoUsuario>(reader).ToList();


            Db.Connection.Close();

            return gestionCreditoResponse;
        }

        public Common.Models.Fertisa.GestionCreditoClienteResponse GetGestionCreditoCliente(int idRuta, DateTime ultimaActualizacion, int page, int pageSize)
        {
            Db.Connection.Open();

            var cmd = Db.Connection.CreateCommand();
            DateTime SqlServerDatetimeMinValue = System.Data.SqlTypes.SqlDateTime.MinValue.Value;
            DateTime MobileDatetimeMinValue = new DateTime(1969, 12, 31, 19, 0, 0);

            var gestionCreditoClienteResponse = new Common.Models.Fertisa.GestionCreditoClienteResponse();

            if (ultimaActualizacion <= MobileDatetimeMinValue)
            {
                ultimaActualizacion = SqlServerDatetimeMinValue;
            }
            else
            {
                ultimaActualizacion.AddMinutes(-15);
            }

            string sqlFormattedDate = ultimaActualizacion.ToString("yyyy-MM-dd HH:mm:ss.fff");

            cmd.CommandText = String.Format("[fertisa].[spGetGestionCreditoCliente] @IdRuta = @IdRuta, @UltimaActualizacion = @UltimaActualizacion, @PageSize = @PageSize, @Page= @Page");
            cmd.Parameters.Add(new SqlParameter("@IdRuta", SqlDbType.Int) { Value = idRuta });
            cmd.Parameters.Add(new SqlParameter("@UltimaActualizacion", SqlDbType.DateTime) { Value = sqlFormattedDate });
            cmd.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int) { Value = pageSize });
            cmd.Parameters.Add(new SqlParameter("@Page", SqlDbType.Int) { Value = page });

            try
            {

                var reader = cmd.ExecuteReader();

                //if (reader.HasRows == true)
                    gestionCreditoClienteResponse.GestionCredito = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.GestionCredito>(reader).ToList();
                reader.NextResult();

               // if (reader.HasRows == true)
                    gestionCreditoClienteResponse.GestionCreditoCliente = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.GestionCreditoCliente>(reader).ToList();
                reader.NextResult();

               // if (reader.HasRows == true)
                    gestionCreditoClienteResponse.GestionCreditoClienteCupo = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.GestionCreditoClienteCupo>(reader).ToList();
                reader.NextResult();

                //if (reader.HasRows == true)
                    gestionCreditoClienteResponse.GestionCreditoClienteDireccion = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.GestionCreditoClienteDireccion>(reader).ToList();
                reader.NextResult();

                //if (reader.HasRows == true)
                    gestionCreditoClienteResponse.GestionCreditoClienteDocumento = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.GestionCreditoClienteDocumento>(reader).ToList();
                reader.NextResult();

                //if (reader.HasRows == true)
                    gestionCreditoClienteResponse.GestionCreditoClienteDocumentoImagen = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.GestionCreditoClienteDocumentoImagen>(reader).ToList();
                reader.NextResult();

                //if (reader.HasRows == true)
                    gestionCreditoClienteResponse.GestionCreditoClienteFamiliar = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.GestionCreditoClienteFamiliar>(reader).ToList();
                reader.NextResult();

                //if (reader.HasRows == true)
                    gestionCreditoClienteResponse.GestionCreditoClienteReferencia = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.GestionCreditoClienteReferencia>(reader).ToList();
                reader.NextResult();

                //if (reader.HasRows == true)
                   gestionCreditoClienteResponse.GestionCreditoClienteSobregiro = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.GestionCreditoClienteSobregiro>(reader).ToList();
                reader.NextResult();


                //if (reader.HasRows == true)
                gestionCreditoClienteResponse.GestionCreditoAudit = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.GestionCreditoAudit>(reader).ToList();
                reader.NextResult();

                //if (reader.HasRows == true)
                gestionCreditoClienteResponse.Cliente = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.ClienteSync>(reader).ToList();
                reader.NextResult();

                //if (reader.HasRows == true)
                gestionCreditoClienteResponse.ClienteCupo = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.ClienteCupoSync>(reader).ToList();
                reader.NextResult();

                //if (reader.HasRows == true)
                gestionCreditoClienteResponse.ClienteDireccion = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.ClienteDireccionSync>(reader).ToList();
                reader.NextResult();

                //if (reader.HasRows == true)
                gestionCreditoClienteResponse.ClienteDocumento = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.ClienteDocumentoSync>(reader).ToList();
                reader.NextResult();

                //if (reader.HasRows == true)
                gestionCreditoClienteResponse.ClienteDocumentoImagen = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.ClienteDocumentoImagenSync>(reader).ToList();
                reader.NextResult();

                //if (reader.HasRows == true)
                gestionCreditoClienteResponse.ClienteFamiliar = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.ClienteFamiliarSync>(reader).ToList();
                reader.NextResult();

                //if (reader.HasRows == true)
                gestionCreditoClienteResponse.ClienteReferencia = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.ClienteReferenciaSync>(reader).ToList();
                //reader.NextResult();








            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                Db.Connection.Close();
            }           

            return gestionCreditoClienteResponse;
        }
        public Common.Models.Fertisa.FileResponse GetFileDocumento(int idgestion, int idcliente, int iddoc, int idimg)
        {
            Db.Connection.Open();

            var cmd = Db.Connection.CreateCommand();
            

            var fileResponse = new Common.Models.Fertisa.FileResponse();

        
            cmd.CommandText = String.Format("[fertisa].[spGetFileDocumento] @IdGestion = @IdGestion, @IdCliente = @IdCliente, @IdClienteDocumento = @IdClienteDocumento, @IdClienteDocumentoImagen= @IdClienteDocumentoImagen");
            cmd.Parameters.Add(new SqlParameter("@IdGestion", SqlDbType.Int) { Value = idgestion });
            cmd.Parameters.Add(new SqlParameter("@IdCliente", SqlDbType.Int) { Value = idcliente });
            cmd.Parameters.Add(new SqlParameter("@IdClienteDocumento", SqlDbType.Int) { Value = iddoc });
            cmd.Parameters.Add(new SqlParameter("@IdClienteDocumentoImagen", SqlDbType.Int) { Value = idimg });

            var reader = cmd.ExecuteReader();

            if (reader.HasRows == true)
                fileResponse.Files = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.FileSync>(reader).ToList();
            
            Db.Connection.Close();

            return fileResponse;
        }

        public Common.Models.Fertisa.ProductoCarteraResponse GetProductoCartera(DateTime ultimaActualizacion, int page, int pageSize)
        {
            Db.Connection.Open();

            var cmd = Db.Connection.CreateCommand();
            DateTime SqlServerDatetimeMinValue = System.Data.SqlTypes.SqlDateTime.MinValue.Value;
            DateTime MobileDatetimeMinValue = new DateTime(1969, 12, 31, 19, 0, 0);

            var response = new Common.Models.Fertisa.ProductoCarteraResponse();

            if (ultimaActualizacion <= MobileDatetimeMinValue)
            {
                ultimaActualizacion = SqlServerDatetimeMinValue;
            }
            else
            {
                ultimaActualizacion.AddMinutes(-15);
            }

            string sqlFormattedDate = ultimaActualizacion.ToString("yyyy-MM-dd HH:mm:ss.fff");

            cmd.CommandText = String.Format("[fertisa].[spGetProductoCartera] @UltimaActualizacion = @UltimaActualizacion, @PageSize = @PageSize, @Page= @Page");
            cmd.Parameters.Add(new SqlParameter("@UltimaActualizacion", SqlDbType.DateTime) { Value = sqlFormattedDate });
            cmd.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int) { Value = pageSize });
            cmd.Parameters.Add(new SqlParameter("@Page", SqlDbType.Int) { Value = page });

            var reader = cmd.ExecuteReader();

            if (reader.HasRows == true)
                response.ProductoCartera = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.ProductoCartera>(reader).ToList();
            reader.NextResult();
            if (reader.HasRows == true)
                response.ProductoCarteraDocumento = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.ProductoCarteraDocumento>(reader).ToList();

            Db.Connection.Close();

            return response;
        }
        public Common.Models.Fertisa.ZonasResponse GetZonas(DateTime ultimaActualizacion, int page, int pageSize)
        {
            Db.Connection.Open();

            var cmd = Db.Connection.CreateCommand();
            DateTime SqlServerDatetimeMinValue = System.Data.SqlTypes.SqlDateTime.MinValue.Value;
            DateTime MobileDatetimeMinValue = new DateTime(1969, 12, 31, 19, 0, 0);

            var response = new Common.Models.Fertisa.ZonasResponse();

            if (ultimaActualizacion <= MobileDatetimeMinValue)
            {
                ultimaActualizacion = SqlServerDatetimeMinValue;
            }
            else
            {
                ultimaActualizacion.AddMinutes(-15);
            }

            string sqlFormattedDate = ultimaActualizacion.ToString("yyyy-MM-dd HH:mm:ss.fff");

            cmd.CommandText = String.Format("[fertisa].[spZonas] @UltimaActualizacion = @UltimaActualizacion, @PageSize = @PageSize, @Page= @Page");
            cmd.Parameters.Add(new SqlParameter("@UltimaActualizacion", SqlDbType.DateTime) { Value = sqlFormattedDate });
            cmd.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int) { Value = pageSize });
            cmd.Parameters.Add(new SqlParameter("@Page", SqlDbType.Int) { Value = page });

            var reader = cmd.ExecuteReader();

            if (reader.HasRows == true)
                response.Pais = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.PaisSync>(reader).ToList();
            reader.NextResult();

            if (reader.HasRows == true)
                response.Zona = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.ZonaSync>(reader).ToList();
            reader.NextResult();

            if (reader.HasRows == true)
                response.Ciudad = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.CiudadSync>(reader).ToList();
            reader.NextResult();

            if (reader.HasRows == true)
                response.Region = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.RegionSync>(reader).ToList();
            reader.NextResult();

            if (reader.HasRows == true)
                response.TipoContribuyente = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.TipoContribuyenteSync>(reader).ToList();
            reader.NextResult();

            if (reader.HasRows == true)
                response.TipoTelefono = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.TipoTelefonoSync>(reader).ToList();

            Db.Connection.Close();

            return response;
        }
        public Common.Models.Fertisa.ClienteProductoResponse GetClienteProducto(int idRuta, DateTime ultimaActualizacion, int page, int pageSize)
        {
            Db.Connection.Open();

            var cmd = Db.Connection.CreateCommand();
            DateTime SqlServerDatetimeMinValue = System.Data.SqlTypes.SqlDateTime.MinValue.Value;
            DateTime MobileDatetimeMinValue = new DateTime(1969, 12, 31, 19, 0, 0);

            var response = new Common.Models.Fertisa.ClienteProductoResponse();

            if (ultimaActualizacion <= MobileDatetimeMinValue)
            {
                ultimaActualizacion = SqlServerDatetimeMinValue;
            }
            else
            {
                ultimaActualizacion.AddMinutes(-15);
            }

            string sqlFormattedDate = ultimaActualizacion.ToString("yyyy-MM-dd HH:mm:ss.fff");
            
            cmd.CommandText = String.Format("[fertisa].[spGetClienteProducto] @IdRuta = @IdRuta,@UltimaActualizacion = @UltimaActualizacion, @PageSize = @PageSize, @Page= @Page");
            cmd.Parameters.Add(new SqlParameter("@IdRuta", SqlDbType.Int) { Value = idRuta });
            cmd.Parameters.Add(new SqlParameter("@UltimaActualizacion", SqlDbType.DateTime) { Value = sqlFormattedDate });
            cmd.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int) { Value = pageSize });
            cmd.Parameters.Add(new SqlParameter("@Page", SqlDbType.Int) { Value = page });

            var reader = cmd.ExecuteReader();

            if (reader.HasRows == true)
                response.ClienteProducto = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.ClienteProductoSync>(reader).ToList();
           
            Db.Connection.Close();

            return response;
        }
        public Common.Models.Fertisa.ClienteCupoResponse GetClienteCupo(int idRuta, DateTime ultimaActualizacion, int page, int pageSize)
        {
            Db.Connection.Open();

            var cmd = Db.Connection.CreateCommand();
            DateTime SqlServerDatetimeMinValue = System.Data.SqlTypes.SqlDateTime.MinValue.Value;
            DateTime MobileDatetimeMinValue = new DateTime(1969, 12, 31, 19, 0, 0);

            var response = new Common.Models.Fertisa.ClienteCupoResponse();

            if (ultimaActualizacion <= MobileDatetimeMinValue)
            {
                ultimaActualizacion = SqlServerDatetimeMinValue;
            }
            else
            {
                ultimaActualizacion.AddMinutes(-15);
            }

            string sqlFormattedDate = ultimaActualizacion.ToString("yyyy-MM-dd HH:mm:ss.fff");
            
            cmd.CommandText = String.Format("[fertisa].[spGetClienteCupo] @IdRuta = @IdRuta,@UltimaActualizacion = @UltimaActualizacion, @PageSize = @PageSize, @Page= @Page");
            cmd.Parameters.Add(new SqlParameter("@IdRuta", SqlDbType.Int) { Value = idRuta });
            cmd.Parameters.Add(new SqlParameter("@UltimaActualizacion", SqlDbType.DateTime) { Value = sqlFormattedDate });
            cmd.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int) { Value = pageSize });
            cmd.Parameters.Add(new SqlParameter("@Page", SqlDbType.Int) { Value = page });

            var reader = cmd.ExecuteReader();

            if (reader.HasRows == true)
                response.ClienteCupo = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.ClienteCupoSync>(reader).ToList();
           
            Db.Connection.Close();

            return response;
        }
        public Common.Models.Fertisa.CxCResponse GetCxC(int idRuta, DateTime ultimaActualizacion, int page, int pageSize)
        {
            Db.Connection.Open();

            var cmd = Db.Connection.CreateCommand();
            DateTime SqlServerDatetimeMinValue = System.Data.SqlTypes.SqlDateTime.MinValue.Value;
            DateTime MobileDatetimeMinValue = new DateTime(1969, 12, 31, 19, 0, 0);

            var response = new Common.Models.Fertisa.CxCResponse();

            if (ultimaActualizacion <= MobileDatetimeMinValue)
            {
                ultimaActualizacion = SqlServerDatetimeMinValue;
            }
            else
            {
                ultimaActualizacion.AddMinutes(-15);
            }

            string sqlFormattedDate = ultimaActualizacion.ToString("yyyy-MM-dd HH:mm:ss.fff");
            
            cmd.CommandText = String.Format("[fertisa].[spGetCxc] @IdRuta = @IdRuta,@UltimaActualizacion = @UltimaActualizacion, @PageSize = @PageSize, @Page= @Page");
            cmd.Parameters.Add(new SqlParameter("@IdRuta", SqlDbType.Int) { Value = idRuta });
            cmd.Parameters.Add(new SqlParameter("@UltimaActualizacion", SqlDbType.DateTime) { Value = sqlFormattedDate });
            cmd.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int) { Value = pageSize });
            cmd.Parameters.Add(new SqlParameter("@Page", SqlDbType.Int) { Value = page });

            var reader = cmd.ExecuteReader();

            if (reader.HasRows == true)
                response.CxC = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.CxCSync>(reader).ToList();
           
            Db.Connection.Close();

            return response;
        }


        public Common.Models.Fertisa.GestionCreditoResponseSync InsertUpdateFull(List<Common.Models.Fertisa.GestionCreditoSync> entityToUpdate, int UsuarioId)
        {
            Db.Connection.Open();
            var cmd = Db.Connection.CreateCommand();

            var response = new Common.Models.Fertisa.GestionCreditoResponseSync();

            response.GestionCreditoResult = new List<Common.Models.Fertisa.GestionCreditoResult>();
            response.GestionCreditoDocumentoResult = new List<Common.Models.Fertisa.GestionCreditoDocumentoResult>();
            response.GestionCreditoDocumentoImagenResult = new List<Common.Models.Fertisa.GestionCreditoDocumentoImagenResult>();


            string infoXml = Rp3.Xml.XmlConverter.ToXml(entityToUpdate);

            cmd.CommandText = String.Format("[fertisa].[spGestionCreditoInsertUpdateFull] @InfoXml, @UserId");

            cmd.Parameters.Add(new SqlParameter("@InfoXml", SqlDbType.Xml) { Value = infoXml });
            cmd.Parameters.Add(new SqlParameter("@UserId", SqlDbType.Int) { Value = UsuarioId });

            var reader = cmd.ExecuteReader();

            if (reader.HasRows == true)
                response.GestionCreditoResult = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.GestionCreditoResult>(reader).ToList();

            reader.NextResult();

            if (reader.HasRows == true)
                response.GestionCreditoDocumentoResult = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.GestionCreditoDocumentoResult>(reader).ToList();

            reader.NextResult();

            if (reader.HasRows == true)
                response.GestionCreditoDocumentoImagenResult = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.GestionCreditoDocumentoImagenResult>(reader).ToList();


            Db.Connection.Close();
            //foreach (var transaccionAuxiliar in transaccionResponse.Codigos)
            //{
            //   transaccionAuxiliar.TransaccionProductoDetalleResult = transaccionProductoDetalleResult.Where(p => p.IdInternoPattern == transaccionAuxiliar.IdInterno).ToList();
            //    transaccionAuxiliar.TransaccionProductoDetalleBeneficio = transaccionProductoDetalleBeneficio.Where(p => p.IdInternoPattern == transaccionAuxiliar.IdInterno).ToList();
            //    transaccionAuxiliar.TransaccionProductoDetalleImpuesto = transaccionProductoDetalleImpuesto.Where(p => p.IdInternoPattern == transaccionAuxiliar.IdInterno).ToList();
            //    transaccionAuxiliar.TransaccionRubroResult = transaccionRubroResult.Where(p => p.IdInternoPattern == transaccionAuxiliar.IdInterno).ToList();
            //}

            return response;
        }

        public Common.Models.Fertisa.ReporteGestionCliente GetReporteGestion(int IdGestion)
        {
            Db.Connection.Open();

            var cmd = Db.Connection.CreateCommand();
            

            var response = new Common.Models.Fertisa.ReporteGestionCliente();

            cmd.CommandText = String.Format("[fertisa].[spGetReporteGestion] @IdGestion = @IdGestion ");
            cmd.Parameters.Add(new SqlParameter("@IdGestion", SqlDbType.Int) { Value = IdGestion });

            var reader = cmd.ExecuteReader();


      

            if (reader.HasRows == true)
                response = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.ReporteGestionCliente>(reader).FirstOrDefault();
            reader.NextResult();

            #region #Cliente Referencia

            if (reader.HasRows == true)
                response.ReferenciasPersonal = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.ReporteGestionCreditoClienteReferencia>(reader).ToList();
            reader.NextResult();
            if (reader.HasRows == true)
                response.ReferenciasBancaria = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.ReporteGestionCreditoClienteReferencia>(reader).ToList();
            reader.NextResult();
            if (reader.HasRows == true)
                response.ReferenciasLaborables = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.ReporteGestionCreditoClienteReferencia>(reader).ToList();
            reader.NextResult();
            if (reader.HasRows == true)
                response.ReferenciasComerciales = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.ReporteGestionCreditoClienteReferencia>(reader).ToList();
            reader.NextResult();
            if (reader.HasRows == true)
                response.ReferenciasGarantia = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.ReporteGestionCreditoClienteReferencia>(reader).ToList();

            #endregion

            #region #GestionCreditoClienteDocumento

            reader.NextResult();
            if (reader.HasRows == true)
                response.GestionCreditoClienteDocumento = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.ReporteGestionCreditoClienteDocumento>(reader).ToList();

            #endregion

            #region #GestionCreditoClienteFamiliar

            reader.NextResult();
            if (reader.HasRows == true)
                response.GestionCreditoClienteFamiliar = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.ReporteGestionCreditoClienteFamiliar>(reader).ToList();

            #endregion

            #region #GestionCreditoClienteCupo

            reader.NextResult();
            if (reader.HasRows == true)
                response.GestionCreditoClienteCupo = ((IObjectContextAdapter)context).ObjectContext.Translate<Common.Models.Fertisa.ReporteGestionCreditoClienteCupo>(reader).ToList();

            #endregion



            Db.Connection.Close();

            return response;
        }

    }
}
