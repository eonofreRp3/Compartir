﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rp3.AgendaComercial.Common.Models.Fertisa
{
    public class GestionCredito
    {
        public GestionCredito()
        {
            this.GestionCreditoCliente = new HashSet<GestionCreditoCliente>();
        }

        
        public int IdGestion { get; set; }
        public int IdTransaccion { get; set; }
        public int IdPuntoOperacion { get; set; }
        public int IdProductoCartera { get; set; }
        public short EstadoTabla { get; set; }
        public string Estado { get; set; }
        public decimal CupoSolicita { get; set; }
        public decimal CupoAprobado { get; set; }
        public string UsrIng { get; set; }
        public System.DateTime FecIng { get; set; }
        public string UsrMod { get; set; }
        public Nullable<System.DateTime> FecMod { get; set; }
        public short TipoSolicitudTabla { get; set; }
        public string TipoSolicitud { get; set; }
        public Nullable<System.DateTime> DateSyncServer { get; set; }
        public Nullable<long> DateSyncServerId { get; set; }
        public Nullable<int> Secuencial { get; set; }
        public Nullable<short> EstadoFaseTabla { get; set; }
        public string EstadoFase { get; set; }
        public string UsrDescartar { get; set; }
        public DateTime? FecDescartar { get; set; }
        public long? FecDescartarTicks
        {
            get
            {
                if (FecDescartar.HasValue)
                    return FecDescartar.Value.Ticks;
                return 0;
            }
            set
            {
                if (value == 0 || value == null)
                    FecDescartar = null;
                else
                    FecDescartar = new DateTime(value.Value);
            }
        }
        public Nullable<bool> Devuelta { get; set; }

        public virtual ProductoCartera ProductoCartera { get; set; }
        public virtual ICollection<GestionCreditoCliente> GestionCreditoCliente { get; set; }

    }

    public class Banco
    {
        public int IdBanco { get; set; }
        public string Descripcion { get; set; }
        public short? IdEstadoTabla { get; set; }
        public string IdEstado { get; set; }
        public bool? PorcentajeComisionProtesto { get; set; }
        public double ComisionProtesto { get; set; }
        public bool PorcentajeInteresProtesto { get; set; }
        public double? InteresProtesto { get; set; }
        public string UsrIng { get; set; }
        public DateTime? FecIng { get; set; }
        public string UsrMod { get; set; }
        public DateTime? FecMod { get; set; }
        public string CodigoExterno { get; set; }
        public int? ComprobanteComisionSinFactura { get; set; }
        public bool? PermiteDiferido { get; set; }

    }
    public class GestionCreditoAudit
    {
        public int IdGestion { get; set; }
        public int IdGestionAudit { get; set; }
        public int IdProductoCartera { get; set; }
        public short EstadoTabla { get; set; }
        public string Estado { get; set; }
        public short EstadoFaseTabla { get; set; }
        public string EstadoFase { get; set; }
        public string Observacion { get; set; }
        public bool? Devuelta { get; set; }
        public string UsrIng { get; set; }
        public DateTime? FecIng { get; set; }
        public long? FecIngTicks
        {
            get
            {
                if (FecIng.HasValue)
                    return FecIng.Value.Ticks;
                return 0;
            }
            set
            {
                if (value == 0 || value == null)
                    FecIng = null;
                else
                    FecIng = new DateTime(value.Value);
            }
        }


    }

    //public class GestionCreditoClienteReferencia
    //{
    //    public int IdGestion { get; set; }
    //    public int? IdCliente { get; set; }
    //    public int? IdTipoIdentificacion { get; set; }
    //    public int? IdPersonaReferencia { get; set; }
    //    public short? TipoReferenciaTabla { get; set; }
    //    public string TipoReferencia { get; set; }
    //    public string Empresa { get; set; }
    //    public short? CargoTabla { get; set; }
    //    public string Cargo { get; set; }
    //    public bool? TrabajoActual { get; set; }
    //    public decimal? Salario { get; set; }
    //    public decimal? Comisiones { get; set; }
    //    public decimal? OtrosIngresos { get; set; }
    //    public DateTime? ReferenciaDesde { get; set; }
    //    public DateTime? ReferenciaHasta { get; set; }
    //    public bool? EmpleoIndependiente { get; set; }
    //    public bool? Afiliado { get; set; }
    //    public string NombreReferencia { get; set; }
    //    public short? ParentescoTabla { get; set; }
    //    public string Parentesco { get; set; }
    //    public string Direccion { get; set; }
    //    public string Telefono { get; set; }
    //    public string Telefono2 { get; set; }
    //    public string IdCiudad { get; set; }
    //    public int? IdSector { get; set; }
    //    public int? IdBanco { get; set; }
    //    public string CuentaBancaria { get; set; }
    //    public short? TipoCuentaTabla { get; set; }
    //    public string TipoCuenta { get; set; }
    //    public string Estado { get; set; }
    //    public string EstadoTabla { get; set; }
    //    public short? SaldosPromedioTabla { get; set; }
    //    public string SaldosPromedio { get; set; }
    //    public short? SaldosPromedioCifraTabla { get; set; }
    //    public string SaldosPromedioCifra { get; set; }
    //    public int? IdMarcaTarjeta { get; set; }
    //    public string NumeroTarjeta { get; set; }
    //    public int? IdClienteDireccion { get; set; }
    //    public string Comentario { get; set; }
    //    public DateTime? FechaNacimiento { get; set; }
    //    public string IdPais { get; set; }
    //    public string CorreoElectronico { get; set; }
    //    public string EstadoCivil { get; set; }

    //}
    public class GestionCreditoFase
    {
        public int IdGestionCreditoFase { get; set; }
        public short? TipoUsuarioTabla { get; set; }
        public string TipoUsuario { get; set; }
        public string Descripcion { get; set; }
        public decimal? TiempoGestion { get; set; }
        public decimal FrecuenciaNotificacion { get; set; }
        public bool UseRangoValor { get; set; }

    }
    public class GestionCreditoUsuario
    {
        public int IdGestionCreditoFase { get; set; }
        public int? IdGestionCreditoUsuario { get; set; }
        public string IdVendedor { get; set; }
        public string IdGerente1 { get; set; }
        public string IdGerente2 { get; set; }
        public string IdUsuario { get; set; }
        public string Email { get; set; }
        public decimal? MontoAprobacionDesde { get; set; }
        public decimal? MontoAprobacionHasta { get; set; }

    }

    /*
    public class CantidadCondicionPago
    {
        public int Cantidad { get; set; }
    }*/

    public class GestionCreditoResponse
    {
        public List<GestionCreditoFase> ResultGestionCreditoFase { get; set; }
        public List<GestionCreditoUsuario> ResultGestionCreditoUsuario { get; set; }
    }

    

    public class GetReporteGestionResponse
    {
        public String Data { get; set; }
    }

    public class GetDocumentoPagareResponse
    {
       public String Data { get; set; }
    }

    public class GestionCreditoClienteRequest
    {
        public GestionCreditoClienteRequest()
        {
            this.GestionCreditoClienteReferenciaRequest = new HashSet<GestionCreditoClienteReferenciaRequest>();
            this.GestionCreditoClienteDocumentoRequest = new HashSet<GestionCreditoClienteDocumentoRequest>();
            this.GestionCreditoClienteFamiliarRequest = new HashSet<GestionCreditoClienteFamiliarRequest>();
        }
        public String TipoPersona { get; set; }
        public String CiudadNombre { get; set; }
        public String IdentificacionCliente { get; set; }
        public String NombreCompleto { get; set; }
        public String IdentificacionRepresentante { get; set; }
        public bool ReferenciaGarantia { get; set; }
       

        public virtual ICollection<GestionCreditoClienteReferenciaRequest> GestionCreditoClienteReferenciaRequest { get; set; }
        public virtual ICollection<GestionCreditoClienteDocumentoRequest> GestionCreditoClienteDocumentoRequest { get; set; }
        public virtual ICollection<GestionCreditoClienteFamiliarRequest> GestionCreditoClienteFamiliarRequest { get; set; }
    }

    public class GestionCreditoClienteFamiliarRequest
    {
        public string NombreCompleto { get; set; }
        public string IdentificacionFamiliar { get; set; }
        public bool Esposa { get; set; }
    }

    public class GestionCreditoClienteDocumentoRequest
    {
        public string Documento { get; set; }
        public decimal Monto { get; set; }
        public DateTime? FechaDocumento { get; set; }
        public long? FechaDocumentoTicks
        {
            get
            {
                if (FechaDocumento.HasValue)
                    return FechaDocumento.Value.Ticks;
                return 0;
            }
            set
            {
                if (value == 0 || value == null)
                    FechaDocumento = null;
                else
                    FechaDocumento = new DateTime(value.Value);
            }
        }
    }

    public class GestionCreditoClienteReferenciaRequest
    {
        public string IdTipoIdentificacion { get; set; }
        public string NombreReferencia { get; set; }
        public string IdentificacionReferencia { get; set; }
        public string IdentificacionGerente { get; set; }       
    }



    public class GestionCreditoResponseSync
    {
        public GestionCreditoResponseSync()
        {
            GestionCreditoResult = new List<GestionCreditoResult>();
            GestionCreditoDocumentoResult = new List<GestionCreditoDocumentoResult>();
            GestionCreditoDocumentoImagenResult = new List<GestionCreditoDocumentoImagenResult>();
        }
        public List<GestionCreditoResult> GestionCreditoResult { get; set; }
        public List<GestionCreditoDocumentoResult> GestionCreditoDocumentoResult { get; set; }
        public List<GestionCreditoDocumentoImagenResult> GestionCreditoDocumentoImagenResult { get; set; }
    }

    public class GestionCreditoResult
    {
        public int IdInterno { get; set; }
        public int? IdServer { get; set; }
        public string Message { get; set; }
    }
    public class GestionCreditoDocumentoResult
    {
        public int IdInterno { get; set; }
        public int? IdServer { get; set; }
        public string Message { get; set; }
    }
    public class GestionCreditoDocumentoImagenResult
    {
        public int IdInterno { get; set; }
        public int? IdServer { get; set; }
        public string Message { get; set; }
    }

    public class GestionCreditoSync
    {
        public GestionCreditoSync()
        {
            this.GestionCreditoCliente = new HashSet<GestionCreditoCliente>();
            this.GestionCreditoAudit = new HashSet<GestionCreditoAudit>();
        }
        public int IdTransaccion { get; set; }
        public int IdInterno { get; set; }
        public int IdPuntoOperacion { get; set; }
        public int IdGestion { get; set; }
        public int IdProductoCartera { get; set; }
        public short EstadoTabla { get; set; }
        public string Estado { get; set; }
        public decimal CupoSolicita { get; set; }
        public decimal CupoAprobado { get; set; }
        public string UsrIng { get; set; }
        public System.DateTime FecIng { get; set; }
        public string UsrMod { get; set; }
        public Nullable<System.DateTime> FecMod { get; set; }
        public short TipoSolicitudTabla { get; set; }
        public string TipoSolicitud { get; set; }
        public Nullable<System.DateTime> DateSyncServer { get; set; }
        public Nullable<long> DateSyncServerId { get; set; }
        public Nullable<int> Secuencial { get; set; }
        public Nullable<short> EstadoFaseTabla { get; set; }
        public string EstadoFase { get; set; }
        public string UsrDescartar { get; set; }
        public DateTime? FecDescartar { get; set; }
        public long? FecDescartarTicks
        {
            get
            {
                if (FecDescartar.HasValue)
                    return FecDescartar.Value.Ticks;
                return 0;
            }
            set
            {
                if (value == 0 || value == null)
                    FecDescartar = null;
                else
                    FecDescartar = new DateTime(value.Value);
            }
        }
        public Nullable<bool> Devuelta { get; set; }
        public virtual ProductoCartera ProductoCartera { get; set; }
        public virtual ICollection<GestionCreditoCliente> GestionCreditoCliente { get; set; }
        public virtual ICollection<GestionCreditoAudit> GestionCreditoAudit { get; set; }
    }

    public class ProductoCarteraResponse
    {
        public ProductoCarteraResponse()
        {
            this.ProductoCartera = new List<ProductoCartera>();
            this.ProductoCarteraDocumento = new List<ProductoCarteraDocumento>();
        }

        public List<ProductoCartera> ProductoCartera { get; set; }
        public List<ProductoCarteraDocumento> ProductoCarteraDocumento { get; set; }
    }

    public class PaisSync
    {
        public string IdPais { get; set; }
        public string Nombre { get; set; }
    }
    public class ZonaSync
    {
        public int IdZona { get; set; }
        public string Descripcion { get; set; }
    }
    public class CiudadSync
    {
        public string IdCiudad { get; set; }
        public string Nombre { get; set; }
    }
    public class RegionSync
    {
        public int IdRegion { get; set; }
        public string CodRegion { get; set; }
        public string Descripcion { get; set; }
    }
    public class TipoTelefonoSync
    {
        public int IdTipoTelefono { get; set; }
        public string CodTipoTelefono { get; set; }
        public string Descripcion { get; set; }
    }
    public class TipoContribuyenteSync
    {
        public string Codigo{ get; set; }
        public string Descripcion { get; set; }
    }

    public class ZonasResponse
    {
        public ZonasResponse()
        {
            this.Pais = new List<PaisSync>();
            this.Zona = new List<ZonaSync>();
            this.Ciudad = new List<CiudadSync>();
            this.Region = new List<RegionSync>();
            this.TipoContribuyente = new List<TipoContribuyenteSync>();
            this.TipoTelefono = new List<TipoTelefonoSync>();
        }

        public List<PaisSync> Pais { get; set; }
        public List<ZonaSync> Zona { get; set; }
        public List<CiudadSync> Ciudad { get; set; }
        public List<RegionSync> Region { get; set; }
        public List<TipoContribuyenteSync> TipoContribuyente { get; set; }
        public List<TipoTelefonoSync> TipoTelefono { get; set; }
    }
    public class ClienteProductoResponse
    {
        public ClienteProductoResponse()
        {
            this.ClienteProducto = new List<ClienteProductoSync>();
        }

        public List<ClienteProductoSync> ClienteProducto { get; set; }
    } 
    public class ClienteCupoResponse
    {
        public ClienteCupoResponse()
        {
            this.ClienteCupo = new List<ClienteCupoSync>();
        }

        public List<ClienteCupoSync> ClienteCupo { get; set; }
    }
    public class CxCResponse
    {
        public CxCResponse()
        {
            this.CxC = new List<CxCSync>();
        }

        public List<CxCSync> CxC { get; set; }
    }
    public class FileSync
    {
        
        public string Archivo { get; set; }
        public string Nombre { get; set; }
        

    }
    public class ClienteCupoSync
    {
        
        public Nullable<int> IdTipoIdentificacion { get; set; }
        public Nullable<int> IdCliente { get; set; }
        public Nullable<int> IdClasificacion { get; set; }
        public Nullable<int> Plazo { get; set; }
        public Nullable<double>  Cupo { get; set; }
        public Nullable<decimal> Potencial { get; set; }
        public Nullable<short>   EstadoTabla { get; set; }
        public Nullable<short>   CondicionPagoCreditoTabla { get; set; }
        public string  IdCondicionPagoCredito { get; set; }
        public string  Estado { get; set; }
        public string  Observacion { get; set; }
  

    } 
    public class CxCSync
    {
        public int IdCxC { get; set; }
        public int IdTipoIdentificacion { get; set; }
        public int IdCliente { get; set; }
        public int IdProductoCartera { get; set; }
        public int IdTipoDocumento { get; set; }
            public DateTime? FechaCAD { get; set; }
        public long? FechaCADTicks
        {
            get
            {
                if (FechaCAD.HasValue)
                    return FechaCAD.Value.Ticks;
                return 0;
            }
            set
            {
                if (value == 0 || value == null)
                    FechaCAD = null;
                else
                    FechaCAD = new DateTime(value.Value);
            }
        }
        public DateTime? FechaDocumento { get; set; }
        public long? FechaDocumentoTicks
        {
            get
            {
                if (FechaDocumento.HasValue)
                    return FechaDocumento.Value.Ticks;
                return 0;
            }
            set
            {
                if (value == 0 || value == null)
                    FechaDocumento = null;
                else
                    FechaDocumento = new DateTime(value.Value);
            }
        }
        public string Comentario { get; set; }
        public string DocReferencia { get; set; }
        public double Total { get; set; }


    }
   
    public class ClienteProductoSync
    {

        public int IdTipoIdentificacion { get; set; }
        public int IdCliente { get; set; }
        public int IdProductoCartera { get; set; }
        public DateTime? ClienteDesde { get; set; }
        public long? ClienteDesdeTicks
        {
            get
            {
                if (ClienteDesde.HasValue)
                    return ClienteDesde.Value.Ticks;
                return 0;
            }
            set
            {
                if (value == 0 || value == null)
                    ClienteDesde = null;
                else
                    ClienteDesde = new DateTime(value.Value);
            }
        }
        public short EstadoClienteProductoTabla { get; set; }
        public string EstadoClienteProducto { get; set; }
        public decimal Cupo { get; set; }
        public decimal ExtraCupo { get; set; }
        public decimal Sobregiro { get; set; }
        public decimal Saldo { get; set; }
        public decimal CupoReservado { get; set; }
        public decimal Compras { get; set; }
        public decimal ComprasMes { get; set; }
        public decimal Anticipos { get; set; }
        public decimal AnticiposMes { get; set; }
        public decimal Pagos { get; set; }
        public decimal PagosMes { get; set; }
        public decimal NotaCreditos { get; set; }
        public decimal NotasCreditosMes { get; set; }
        public decimal ChequesPosfechados { get; set; }
        public decimal ChequesPosfechadosMes { get; set; }
        public decimal ComprasRespaldadas { get; set; }
        public DateTime? UltimaCompra { get; set; }
        public long? UltimaCompraTicks
        {
            get
            {
                if (UltimaCompra.HasValue)
                    return UltimaCompra.Value.Ticks;
                return 0;
            }
            set
            {
                if (value == 0 || value == null)
                    UltimaCompra = null;
                else
                    UltimaCompra = new DateTime(value.Value);
            }
        }
        public DateTime? UltimoPago { get; set; }

        public long? UltimoPagoTicks
        {
            get
            {
                if (UltimoPago.HasValue)
                    return UltimoPago.Value.Ticks;
                return 0;
            }
            set
            {
                if (value == 0 || value == null)
                    UltimoPago = null;
                else
                    UltimoPago = new DateTime(value.Value);
            }
        }
        public short CalificacionTabla { get; set; }
        public string Calificacion { get; set; }
        public int FacturasVencidas { get; set; }
        public decimal MontoVencido { get; set; }
        public decimal ProformasAutorizadasAutomaticas { get; set; }
        public decimal ProformasNegadasAutomaticas { get; set; }
        public decimal ProformasAutorizadasManuales { get; set; }
        public decimal ProformasNegadasManuales { get; set; }
        public int ChequeProtestado { get; set; }
        public decimal ChequeProtestadoMonto { get; set; }
        public decimal? PromedioCompra { get; set; }
        public int CantidadCupoReservado { get; set; }
        public int CantidadComprasRespaldadas { get; set; }
        public decimal ChequesVencidosMonto { get; set; }
        public int CantidadChequesVencidos { get; set; }
        public decimal NotaDebitoMonto { get; set; }
        public int CantidadNotaDebito { get; set; }
        public int CantidadChequesPosfechados { get; set; }
        public int CantidadNotaCreditos { get; set; }
        public decimal LetraCambioMonto { get; set; }
        public int CantidadLetraCambio { get; set; }
        public short? MotivoTabla { get; set; }
        public string Motivo { get; set; }
        public int? DiasVencidos { get; set; }
        public decimal? DevolucionesMayorista { get; set; }
        public decimal? NotasCreditosPendientes { get; set; }
        public decimal? SaldoComprasDiferidas { get; set; }
        public int? ProformasAutorizadasCantidad { get; set; }
        public decimal? ComprasNoRespaldadas { get; set; }
        public int? CantidadComprasNoRespaldadas { get; set; }
        public decimal? ChequeGarantiaRespaldado { get; set; }
        public int? ChequeGarantiaRespaldadoCant { get; set; }
        public decimal? ChequeGarantiaNoRespaldado { get; set; }
        public int? ChequeGarantiaNoRespaldadoCant { get; set; }
        public int? NotasCreditosPendienteCant { get; set; }
        public decimal? ChequePostergados { get; set; }
        public int? ChequePostergadosCant { get; set; }
        public int? AnticiposCant { get; set; }



    }
    public class FileResponse
    {
        public FileResponse()
        {
            this.Files = new List<FileSync>();
        }

        public List<FileSync> Files { get; set; }

    }

   


    public class ClienteSync
    {
        public Nullable<int> IdRegion { get; set; }
        public string IdTipoContribuyente { get; set; }
        public Nullable<int> IdTipoIdentificacion { get; set; }
        public Nullable<int> IdCliente { get; set; }
        public double CodigoAlterno { get; set; }
        public bool DatosGenerales { get; set; }
        public bool DatosFamiliares { get; set; }
        public bool Referencias { get; set; }
        public bool Documentos { get; set; }
        public bool Garantia { get; set; }
        public string NombreComercial { get; set; }
        public string IdentificacionRepresentante { get; set; }
        public Nullable<int> IdTipoIdentificacionRepresentante { get; set; }
        public string RepresentanteLegal { get; set; }
        public string Nombre1 { get; set; }
        public string IdCiudadNacimiento { get; set; }
        public string Nombre2 { get; set; }
        public string Apellido1 { get; set; }
        public string Apellido2 { get; set; }
        public string NombreCompleto { get; set; }
        public Nullable<int> IdClienteGrupo { get; set; }
        public string CorreoElectronico { get; set; }
        public short GeneroTabla { get; set; }
        public string Genero { get; set; }
        public short EstadoCivilTabla { get; set; }
        public string EstadoCivil { get; set; }

        public DateTime? FechaNacimiento { get; set; }
        public long? FechaNacimientoTicks
        {
            get
            {
                if (FechaNacimiento.HasValue)
                    return FechaNacimiento.Value.Ticks;
                return 0;
            }
            set
            {
                if (value == 0 || value == null)
                    FechaNacimiento = null;
                else
                    FechaNacimiento = new DateTime(value.Value);
            }
        }
        public Nullable<int> IdCategoria { get; set; }
        public Nullable<int> IdTipoCliente { get; set; }
        public string IdPais { get; set; }
        public Nullable<int> IdZona { get; set; }
        public Nullable<short> TablaTipoPersona { get; set; }
        public string TipoPersona { get; set; }
        public string IdParroquia { get; set; }
        public Nullable<short> TablaOrigenIngreso { get; set; }
        public string OrigenIngreso { get; set; }
        public string OrigenIngresoSecundario { get; set; }
        public Nullable<int> OrigenIngresoAnios { get; set; }
        public Nullable<int> OrigenIngresoSecundarioAnios { get; set; }
        public Nullable<short> TipoActividadTabla { get; set; }
        public string IdTipoActividad { get; set; }
        public Nullable<short> TipoViviendaTabla { get; set; }
        public string IdTipoVivienda { get; set; }
        public Nullable<short> ProduccionTabla { get; set; }
        public string IdProduccion { get; set; }
        public string UsrIng { get; set; }
        public System.DateTime FecIng { get; set; }
        public string UsrMod { get; set; }
        public Nullable<System.DateTime> FecMod { get; set; }
        public Nullable<System.DateTime> DateSyncServer { get; set; }
        public Nullable<long> DateSyncServerId { get; set; }
        public Nullable<short> EstadoTabla { get; set; }
        public Nullable<short> LocalHectareaTabla { get; set; }
        public string Estado { get; set; }
        public string LocalHectarea { get; set; }
        public Nullable<decimal> CupoSolicitado { get; set; }
        public Nullable<decimal> CupoActual { get; set; }
        public Nullable<int> Plazo { get; set; }
        public Nullable<int> Hectarea { get; set; }
        public Nullable<int> HectareasAlquilada { get; set; }
        public Nullable<int> IdTipoCultivo { get; set; }
        public Nullable<int> IdCondicionPago { get; set; }
        public Nullable<int> HaciendaTotales { get; set; }
        public Nullable<int> HaciendaProductivas { get; set; }

    }
    public class ClienteDireccionSync
    {
        public Nullable<int> Tiempo { get; set; }
        public Nullable<int> IdTipoTelefono { get; set; }
        public Nullable<int> IdTipoIdentificacion { get; set; }
        public Nullable<int> IdCliente { get; set; }
        public Nullable<int> IdClienteDireccion { get; set; }
        public short TipoDireccionTabla { get; set; }
        public string TipoDireccion { get; set; }
        public string Direccion { get; set; }
        public string Telefono1 { get; set; }
        public string Telefono2 { get; set; }
        public string Telefono3 { get; set; }
        public string IdCiudad { get; set; }
        public string Ubicacion { get; set; }
        public Nullable<int> IdSector { get; set; }
        public bool DireccionPrincipal { get; set; }
        public bool EnvioEstadoCta { get; set; }
        public string UsrIng { get; set; }
        public System.DateTime FecIng { get; set; }
        public string UsrMod { get; set; }
        public Nullable<System.DateTime> FecMod { get; set; }

    }
    public class ClienteDocumentoSync
    {
        public Nullable<int> IdTipoIdentificacion { get; set; }
        public Nullable<int> IdCliente { get; set; }
        public Nullable<int> IdClienteDocumento { get; set; }
        public short DocumentoTabla { get; set; }
        public string Documento { get; set; }
        public string Comentario { get; set; }
        public Nullable<int> Cantidad { get; set; }
        public Nullable<System.DateTime> FechaVencimientoDoc { get; set; }
        public long? FechaVencimientoDocTicks
        {
            get
            {
                if (FechaVencimientoDoc.HasValue)
                    return FechaVencimientoDoc.Value.Ticks;
                return 0;
            }
            set
            {
                if (value == 0 || value == null)
                    FechaVencimientoDoc = null;
                else
                    FechaVencimientoDoc = new DateTime(value.Value);
            }
        }
        public Nullable<System.DateTime> FechaDocumento { get; set; }
        public long? FechaDocumentoTicks
        {
            get
            {
                if (FechaDocumento.HasValue)
                    return FechaDocumento.Value.Ticks;
                return 0;
            }
            set
            {
                if (value == 0 || value == null)
                    FechaDocumento = null;
                else
                    FechaDocumento = new DateTime(value.Value);
            }
        }
        public byte[] Archivo { get; set; }
        public string ArchivoNombre { get; set; }
        public string UsrIng { get; set; }
        public System.DateTime FecIng { get; set; }
        public string UsrMod { get; set; }
        public Nullable<System.DateTime> FecMod { get; set; }
        public Nullable<bool> Excepcion { get; set; }
        public Nullable<decimal> Monto { get; set; }

    }
    public class ClienteDocumentoImagenSync
    {
        public Nullable<int> IdTipoIdentificacion { get; set; }
        public Nullable<int> IdCliente { get; set; }
        public Nullable<int> IdClienteDocumento { get; set; }
        public Nullable<int> IdClienteDocumentoImagen { get; set; }
        public string ArchivoNombre { get; set; }
        public byte[] Imagen { get; set; }
        public string UsrIng { get; set; }
        public System.DateTime FecIng { get; set; }
        public string UsrMod { get; set; }
        public Nullable<System.DateTime> FecMod { get; set; }

    }
    public class ClienteFamiliarSync
    {
        public Nullable<int> IdTipoIdentificacion { get; set; }
        public Nullable<int> IdCliente { get; set; }
        public Nullable<int> IdPersonaFamiliar { get; set; }
        public Nullable<int> IdTipoIdentificacionFamiliar { get; set; }
        public string IdentificacionFamiliar { get; set; }
        public string Nombre1 { get; set; }
        public string Nombre2 { get; set; }
        public string Apellido1 { get; set; }
        public string Apellido2 { get; set; }
        public DateTime? FechaNacimiento { get; set; }
        public long? FechaNacimientoTicks
        {
            get
            {
                if (FechaNacimiento.HasValue)
                    return FechaNacimiento.Value.Ticks;
                return 0;
            }
            set
            {
                if (value == 0 || value == null)
                    FechaNacimiento = null;
                else
                    FechaNacimiento = new DateTime(value.Value);
            }
        }
        public bool Esposa { get; set; }
        public bool Hijo { get; set; }
        public string Genero { get; set; }
        public short GeneroTabla { get; set; }
        public Nullable<int> Dependientes { get; set; }
        public string Profesion { get; set; }
        public string Empresa { get; set; }
        public string Direccion { get; set; }
        public Nullable<int> Antiguedad { get; set; }
        public Nullable<double> Sueldo { get; set; }
        public string Cargo { get; set; }
        public string Telefono { get; set; }
        public string IdPais { get; set; }
        public string UsrIng { get; set; }
        public System.DateTime FecIng { get; set; }
        public string UsrMod { get; set; }
        public Nullable<System.DateTime> FecMod { get; set; }
        public Nullable<System.DateTime> DateSyncServer { get; set; }
        public Nullable<long> DateSyncServerId { get; set; }

    }
    public class ClienteReferenciaSync
    {
        public int IdCliente { get; set; }
        public int IdTipoIdentificacion { get; set; }
        public int IdPersonaReferencia { get; set; }
        public short TipoReferenciaTabla { get; set; }
        public string TipoReferencia { get; set; }
        public string Empresa { get; set; }
        public short CargoTabla { get; set; }
        public string Cargo { get; set; }
        public bool TrabajoActual { get; set; }
        public decimal Salario { get; set; }
        public decimal Comisiones { get; set; }
        public decimal OtrosIngresos { get; set; }

        public DateTime? ReferenciaDesde { get; set; }
        public long? ReferenciaDesdeTicks
        {
            get
            {
                if (ReferenciaDesde.HasValue)
                    return ReferenciaDesde.Value.Ticks;
                return 0;
            }
            set
            {
                if (value == 0 || value == null)
                    ReferenciaDesde = null;
                else
                    ReferenciaDesde = new DateTime(value.Value);
            }
        }

        public DateTime? FechaNacimiento { get; set; }
        public long? FechaNacimientoTicks
        {
            get
            {
                if (FechaNacimiento.HasValue)
                    return FechaNacimiento.Value.Ticks;
                return 0;
            }
            set
            {
                if (value == 0 || value == null)
                    FechaNacimiento = null;
                else
                    FechaNacimiento = new DateTime(value.Value);
            }
        }

        public DateTime? ReferenciaHasta { get; set; }
        public long? ReferenciaHastaTicks
        {
            get
            {
                if (ReferenciaHasta.HasValue)
                    return ReferenciaHasta.Value.Ticks;
                return 0;
            }
            set
            {
                if (value == 0 || value == null)
                    ReferenciaHasta = null;
                else
                    ReferenciaHasta = new DateTime(value.Value);
            }
        }
        public bool EmpleoIndependiente { get; set; }
        public bool Afiliado { get; set; }
        public string NombreReferencia { get; set; }
        public short ParentescoTabla { get; set; }
        public string Parentesco { get; set; }
        public string Direccion { get; set; }
        public string Telefono { get; set; }
        public string Telefono2 { get; set; }
        public string IdCiudad { get; set; }
        public Nullable<int> IdSector { get; set; }
        public Nullable<int> IdBanco { get; set; }
        public string CuentaBancaria { get; set; }
        public short TipoCuentaTabla { get; set; }
        public string TipoCuenta { get; set; }
        public string Estado { get; set; }
        public Nullable<short> EstadoTabla { get; set; }
        public short SaldosPromedioTabla { get; set; }
        public string SaldosPromedio { get; set; }
        public short SaldosPromedioCifraTabla { get; set; }
        public string SaldosPromedioCifra { get; set; }
        public Nullable<int> IdMarcaTarjeta { get; set; }
        public string NumeroTarjeta { get; set; }
        public Nullable<int> IdClienteDireccion { get; set; }
        public string Comentario { get; set; }
        public string UsrIng { get; set; }
        public System.DateTime FecIng { get; set; }
        public string UsrMod { get; set; }
        public Nullable<System.DateTime> FecMod { get; set; }
        public Nullable<System.DateTime> DateSyncServer { get; set; }
        public Nullable<long> DateSyncServerId { get; set; }
        public Nullable<short> TablaTipoPersona { get; set; }
        public string IdPais { get; set; }
        public string CorreoElectronico { get; set; }
        public string EstadoCivil { get; set; }
        public string TipoPersona { get; set; }
        public string NombreGerente { get; set; }
        public string IdentificacionGerente { get; set; }
        public string IdentificacionReferencia { get; set; }
        public Nullable<int> TipoIdentificacionGerente { get; set; }
        public Nullable<int> TipoIdentificacionReferencia { get; set; }

    }


    public class GestionCreditoClienteResponse
    {
        public GestionCreditoClienteResponse()
        {
            this.GestionCredito = new List<GestionCredito>();
            this.GestionCreditoCliente = new List<GestionCreditoCliente>();
            this.GestionCreditoClienteCupo = new List<GestionCreditoClienteCupo>();
            this.GestionCreditoClienteDireccion = new List<GestionCreditoClienteDireccion>();
            this.GestionCreditoClienteDocumento = new List<GestionCreditoClienteDocumento>();
            this.GestionCreditoClienteDocumentoImagen = new List<GestionCreditoClienteDocumentoImagen>();
            this.GestionCreditoClienteFamiliar = new List<GestionCreditoClienteFamiliar>();
            this.GestionCreditoClienteReferencia = new List<GestionCreditoClienteReferencia>();
            this.GestionCreditoClienteSobregiro = new List<GestionCreditoClienteSobregiro>();
            this.GestionCreditoAudit = new List<GestionCreditoAudit>();
            this.Cliente = new List<ClienteSync>();
            this.ClienteDireccion = new List<ClienteDireccionSync>();
            this.ClienteCupo = new List<ClienteCupoSync>();
            this.ClienteDocumento = new List<ClienteDocumentoSync>();
            this.ClienteDocumentoImagen = new List<ClienteDocumentoImagenSync>();
            this.ClienteFamiliar = new List<ClienteFamiliarSync>();
            this.ClienteReferencia = new List<ClienteReferenciaSync>();
        }
        public List<GestionCredito> GestionCredito { get; set; }
        public List<GestionCreditoCliente> GestionCreditoCliente { get; set; }
        public List<GestionCreditoClienteCupo> GestionCreditoClienteCupo { get; set; }
        public List<GestionCreditoClienteDireccion> GestionCreditoClienteDireccion { get; set; }
        public List<GestionCreditoClienteDocumento> GestionCreditoClienteDocumento { get; set; }
        public List<GestionCreditoClienteDocumentoImagen> GestionCreditoClienteDocumentoImagen { get; set; }
        public List<GestionCreditoClienteFamiliar> GestionCreditoClienteFamiliar { get; set; }
        public List<GestionCreditoClienteReferencia> GestionCreditoClienteReferencia { get; set; }
        public List<GestionCreditoClienteSobregiro> GestionCreditoClienteSobregiro { get; set; }
        public List<GestionCreditoAudit> GestionCreditoAudit { get; set; }
        public List<ClienteSync> Cliente { get; set; }
        public List<ClienteCupoSync> ClienteCupo { get; set; }
        public List<ClienteDireccionSync> ClienteDireccion { get; set; }
        public List<ClienteDocumentoSync> ClienteDocumento { get; set; }
        public List<ClienteDocumentoImagenSync> ClienteDocumentoImagen { get; set; }
        public List<ClienteFamiliarSync> ClienteFamiliar { get; set; }
        public List<ClienteReferenciaSync> ClienteReferencia { get; set; }

    }

}
