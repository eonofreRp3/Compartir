ALTER TABLE fertisa.tbGestionCredito ADD IdPedido INT NULL
ALTER TABLE fertisa.tbGestionCredito ADD IdRuta INT NULL